#include "arduino.h"
void connect4G (String cmd, char *res);
void EC800NOnenet_init(void);
void OnenetMQTT_SENDData(int tempdata,int humidata);
