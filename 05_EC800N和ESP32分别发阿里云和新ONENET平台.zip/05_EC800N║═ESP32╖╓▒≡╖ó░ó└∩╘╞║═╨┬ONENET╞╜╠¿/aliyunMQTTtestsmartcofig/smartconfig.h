#include <WiFi.h>
#include <esp_wifi.h>
void SmartConfig();
bool AutoConfig();
